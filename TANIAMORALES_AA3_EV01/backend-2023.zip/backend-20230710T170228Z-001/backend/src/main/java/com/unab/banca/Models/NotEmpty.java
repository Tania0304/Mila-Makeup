package com.unab.banca.Models;

public @interface NotEmpty {

}
