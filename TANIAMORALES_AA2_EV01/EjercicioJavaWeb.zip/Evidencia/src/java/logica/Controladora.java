package logica;
import java.util.List;
import persistencia.ControladoraPersistencia;

public class Controladora {
    ControladoraPersistencia controlPersis = new ControladoraPersistencia ();

    //USUARIOS
    public void crearUsuario(Usuario usu){
        controlPersis.crearUsuario(usu);
    }
    
    public List<Usuario> traerUsuarios(){
        return controlPersis.traerUsuarios();
    }
    
    public void borrarUsuario(int id_eliminar) {
        controlPersis.borrarUsuario(id_eliminar);
    }
    
    public Usuario traerUsuario(int id_editar_user) {
        return controlPersis.traerUsuario(id_editar_user);

    }
    
    public void editarUsuario(Usuario usu) {
        controlPersis.editarUsuario(usu);
    }
    
    //PRODUCTOS
    public void crearProducto(Producto prod){
        controlPersis.crearProducto(prod);
    }
    
    public List<Producto> traerProducto(){
        return controlPersis.traerProductos();
    }
    
    public void borrarProducto(int id_eliminar_p) {
        controlPersis.borrarProducto(id_eliminar_p);
    }

    public Producto traerProducto(int id_editar_product) {
        return controlPersis.traerProducto(id_editar_product);
    
    }

    public void editarProducto(Producto prod) {
        controlPersis.editarProducto(prod);
    
    }

    
    
}
