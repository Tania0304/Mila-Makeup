
package persistencia;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import logica.Producto;
import logica.Usuario;
import persistencia.exceptions.NonexistentEntityException;

public class ControladoraPersistencia {
    UsuarioJpaController usuJpa = new UsuarioJpaController();
    ProductoJpaController prodJpa = new ProductoJpaController();
    
    //Operacion CREATE
    public void crearUsuario(Usuario usu){
        usuJpa.create(usu);
    }
    
    //Operacion READ
    public List<Usuario> traerUsuarios(){
        return usuJpa.findUsuarioEntities();
        
    }
    
    //Operacion DELETE
    public void borrarUsuario(int id_eliminar) {
        try {
            usuJpa.destroy(id_eliminar);
        } catch (NonexistentEntityException ex) {
            Logger.getLogger(ControladoraPersistencia.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    //Operacion EDIT
     public Usuario traerUsuario(int id_editar_user) {
         return usuJpa.findUsuario(id_editar_user);
    }
    
    public void editarUsuario(Usuario usu) {
        try {
            usuJpa.edit(usu);
        } catch (Exception ex) {
            Logger.getLogger(ControladoraPersistencia.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
     
     
    //Operacion CREATE PRODUCTO
    public void crearProducto(Producto prod){
        prodJpa.create(prod);
    }
    //Operacion READ PRODUCTO
    public List<Producto> traerProductos(){
        return prodJpa.findProductoEntities();
    }

    //Operacion DELETE PRODUCTO
    public void borrarProducto(int id_eliminar_p) {
        try {
            prodJpa.destroy(id_eliminar_p);
        } catch (NonexistentEntityException ex) {
            Logger.getLogger(ControladoraPersistencia.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    //Operacion EDIT PRODUCTO
    public Producto traerProducto(int id_editar_product) {
        return prodJpa.findProducto(id_editar_product);
    }

    public void editarProducto(Producto prod) {
        try {
            prodJpa.edit(prod);
        } catch (Exception ex) {
            Logger.getLogger(ControladoraPersistencia.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

   


}
