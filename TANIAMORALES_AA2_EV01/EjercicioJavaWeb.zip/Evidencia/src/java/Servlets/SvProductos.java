package Servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import logica.Controladora;
import logica.Producto;

@WebServlet(name = "SvProductos", urlPatterns = {"/SvProductos"})
public class SvProductos extends HttpServlet {
Controladora control = new Controladora();
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Producto> listaProducto = new ArrayList<>();
        listaProducto = control.traerProducto();
        
        HttpSession misesion = request.getSession();
        misesion.setAttribute("listaProducto", listaProducto);

        response.sendRedirect("mostrarProductos.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String categoria = request.getParameter("categoria");
        String subCategoria = request.getParameter("subcategoria");
        String nombreProducto = request.getParameter("nombreproducto");
        String marca = request.getParameter("marca");
        String precio = request.getParameter("precio");
        int precioReal = Integer.parseInt(precio);
    
        Producto prod = new Producto();
        prod.setCategoria(categoria);
        prod.setSubCategoria(subCategoria);
        prod.setNombreProducto(nombreProducto);
        prod.setMarca(marca);
        prod.setPrecio(precioReal);
        
        control.crearProducto(prod);
        
        response.sendRedirect("index.jsp");
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
