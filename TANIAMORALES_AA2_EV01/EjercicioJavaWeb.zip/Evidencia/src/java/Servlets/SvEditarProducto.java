
package Servlets;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import logica.Controladora;
import logica.Producto;
import logica.Usuario;

@WebServlet(name = "SvEditarProducto", urlPatterns = {"/SvEditarProducto"})
public class SvEditarProducto extends HttpServlet {
Controladora control = new Controladora();
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        int id_editar_product = Integer.parseInt(request.getParameter("id_productoEdit"));
        Producto prod = control.traerProducto(id_editar_product);
        
        HttpSession misesion = request.getSession();
        misesion.setAttribute("prodEditar", prod);
        
        response.sendRedirect("editarProducto.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String categoria = request.getParameter("categoria");
        String subCategoria = request.getParameter("subcategoria");
        String nombreProducto = request.getParameter("nombreproducto");
        String marca = request.getParameter("marca");
        String precio = request.getParameter("precio");
        int precioReal = Integer.parseInt(precio);
        
        Producto prod = (Producto) request.getSession().getAttribute("prodEditar");
    
       
        prod.setCategoria(categoria);
        prod.setSubCategoria(subCategoria);
        prod.setNombreProducto(nombreProducto);
        prod.setMarca(marca);
        prod.setPrecio(precioReal);
        
        control.editarProducto(prod);
        
        response.sendRedirect("index.jsp");
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
